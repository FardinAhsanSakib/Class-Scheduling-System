# University-Routine-Management-System
To make the routine making process smooth
